// 'listen' 'silent'
// 'elbow' 'below'

// 'elbows' 'below' NOT anagrams

// 'listens' 'silent' NOT anagrams

// 'conversation' 'voices rant on' ARE anagrams

// 'STATE' 'taste' ARE anagrams